package com.ecogrocery.delivery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(32, 135, 70);
    private static final int DARK = Color.rgb(29, 48, 35);
    private static final int PALE = Color.rgb(241, 248, 242);
    private LinearLayout root, content;
    private SharedPreferences prefs;
    private boolean online;
    private String currentTab = "Home";
    private final ArrayList<Order> orders = new ArrayList<>();

    static class Order {
        String id, customer, phone, address, items, status, otp;
        int amount, fee;
        boolean rejected;
        Order(String id, String customer, String phone, String address,
              String items, int amount, int fee, String status, String otp) {
            this.id=id; this.customer=customer; this.phone=phone;
            this.address=address; this.items=items; this.amount=amount;
            this.fee=fee; this.status=status; this.otp=otp;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("eco_delivery", MODE_PRIVATE);
        online = prefs.getBoolean("online", false);
        seedOrders();
        showLogin();
    }

    private void seedOrders() {
        orders.add(new Order("ECO-1048","Aarav Sharma","9876543210",
            "Boring Road, Patna, Bihar","Apples 1kg, Milk 2L, Bread 1",
            485,45,"Assigned","4821"));
        orders.add(new Order("ECO-1049","Priya Kumari","9876501234",
            "Kankarbagh, Patna, Bihar","Potato 2kg, Onion 1kg, Tomato 1kg",
            320,35,"Assigned","7316"));
        orders.add(new Order("ECO-1050","Rahul Kumar","9876512345",
            "Patliputra Colony, Patna, Bihar","Rice 5kg, Cooking Oil 1L",
            760,55,"Delivered","2094"));
        restoreStatuses();
    }

    private void restoreStatuses() {
        for (Order o: orders) o.status = prefs.getString("status_"+o.id, o.status);
    }

    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private TextView action(String text, int color) {
        TextView v = label(text, 14, Color.WHITE, true);
        v.setGravity(Gravity.CENTER); v.setPadding(dp(14),dp(12),dp(14),dp(12));
        v.setBackground(shape(color, 12)); return v;
    }

    private void showLogin() {
        root = column(); root.setGravity(Gravity.CENTER); root.setPadding(dp(24),dp(24),dp(24),dp(24));
        root.setBackgroundColor(PALE);
        TextView logo = label("🌿", 54, GREEN, true); logo.setGravity(Gravity.CENTER);
        root.addView(logo, lp(-1,-2));
        TextView title = label("ECO DELIVERY PARTNER", 24, GREEN, true);
        title.setGravity(Gravity.CENTER); title.setPadding(0,dp(10),0,dp(6));
        root.addView(title, lp(-1,-2));
        TextView sub = label("Your delivery journey starts here", 14, DARK, false);
        sub.setGravity(Gravity.CENTER); root.addView(sub, lp(-1,-2));
        EditText phone = new EditText(this); phone.setHint("Demo mobile number");
        phone.setInputType(3); phone.setText("9876543210");
        root.addView(phone, lp(-1,55));
        EditText pass = new EditText(this); pass.setHint("Demo password");
        pass.setInputType( classPassword()); pass.setText("123456");
        root.addView(pass, lp(-1,55));
        TextView login = action("LOGIN TO DEMO APP", GREEN);
        LinearLayout.LayoutParams m=lp(-1,52); m.topMargin=dp(18); root.addView(login,m);
        login.setOnClickListener(v -> {
            if (phone.getText().toString().trim().length()<10 || pass.length()<4) {
                toast("Enter a valid demo mobile number and password"); return;
            }
            prefs.edit().putBoolean("logged_in",true)
                .putString("partner_name","Demo Delivery Partner").apply();
            showDashboard();
        });
        TextView note=label("DEMO ACCESS  •  Any 10-digit number / 4+ character password",11,Color.GRAY,false);
        note.setGravity(Gravity.CENTER); note.setPadding(0,dp(18),0,0); root.addView(note,lp(-1,-2));
        setContentView(root);
    }

    private int classPassword() { return 0x00000081; }

    private void showDashboard() {
        root=column(); root.setBackgroundColor(PALE);
        LinearLayout header=column(); header.setPadding(dp(18),dp(20),dp(18),dp(18));
        header.setBackground(shape(GREEN,0));
        header.addView(label("🌿 ECO DELIVERY PARTNER",20,Color.WHITE,true));
        header.addView(label("Hello, Demo Delivery Partner",14,Color.WHITE,false));
        LinearLayout statusRow=new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView status=label(online?"● YOU ARE ONLINE":"● YOU ARE OFFLINE",14,Color.WHITE,true);
        statusRow.addView(status,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView toggle=action(online?"GO OFFLINE":"GO ONLINE",online?Color.DKGRAY:Color.rgb(20,90,45));
        statusRow.addView(toggle,lp(-2,42));
        toggle.setOnClickListener(v->{ online=!online; prefs.edit().putBoolean("online",online).apply(); showDashboard(); });
        header.addView(statusRow); root.addView(header);

        LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(8),dp(8),dp(8),dp(8));
        String[] tabs={"Home","Orders","Earnings","Profile"};
        for(String tab:tabs){
            TextView b=label(tab,13,tab.equals(currentTab)?GREEN:DARK,true);
            b.setGravity(Gravity.CENTER); nav.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));
            b.setOnClickListener(v->{currentTab=tab;showDashboard();});
        }
        root.addView(nav);
        ScrollView scroll=new ScrollView(this); content=column(); content.setPadding(dp(16),dp(6),dp(16),dp(20));
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(currentTab.equals("Home")) homeContent();
        else if(currentTab.equals("Orders")) ordersContent();
        else if(currentTab.equals("Earnings")) earningsContent();
        else profileContent();
        setContentView(root);
    }

    private void heading(String s) {
        TextView t=label(s,20,DARK,true); t.setPadding(0,dp(8),0,dp(12)); content.addView(t);
    }

    private void homeContent() {
        heading("Delivery dashboard");
        int active=0, done=0;
        for(Order o:orders){if(o.status.equals("Delivered"))done++;else if(!o.rejected)active++;}
        LinearLayout stats=new LinearLayout(this);
        stats.addView(statCard("ACTIVE ORDERS",String.valueOf(active)),new LinearLayout.LayoutParams(0,dp(94),1));
        stats.addView(statCard("COMPLETED",String.valueOf(done)),new LinearLayout.LayoutParams(0,dp(94),1));
        content.addView(stats);
        heading("Assigned to you");
        boolean found=false;
        for(Order o:orders) if(!o.rejected && !o.status.equals("Delivered")) { orderCard(o); found=true; }
        if(!found) content.addView(label("No active orders. Ask your admin to assign an order.",14,Color.GRAY,false));
        TextView demo=label("DEMO MODE: These sample orders are stored on this device only.",11,Color.GRAY,false);
        demo.setPadding(0,dp(18),0,0); content.addView(demo);
    }

    private View statCard(String title,String value) {
        LinearLayout c=column(); c.setPadding(dp(12),dp(12),dp(8),dp(8)); c.setBackground(shape(Color.WHITE,14));
        c.addView(label(title,10,Color.GRAY,true)); c.addView(label(value,26,GREEN,true));
        LinearLayout.LayoutParams p=lp(-1,94); p.setMargins(dp(3),0,dp(3),0); c.setLayoutParams(p); return c;
    }

    private void ordersContent() {
        heading("My orders");
        for(Order o:orders) if(!o.rejected) orderCard(o);
    }

    private void orderCard(Order o) {
        LinearLayout card=column(); card.setPadding(dp(14),dp(13),dp(14),dp(13));
        card.setBackground(shape(Color.WHITE,14));
        LinearLayout.LayoutParams cp=lp(-1,-2); cp.bottomMargin=dp(12); content.addView(card,cp);
        LinearLayout top=new LinearLayout(this);
        top.addView(label(o.id,16,DARK,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(label(o.status,12,GREEN,true)); card.addView(top);
        card.addView(label(o.customer+"  •  "+o.phone,14,DARK,true));
        card.addView(label(o.address,13,Color.DKGRAY,false));
        TextView items=label("Items: "+o.items,13,Color.GRAY,false); items.setPadding(0,dp(5),0,dp(5)); card.addView(items);
        card.addView(label("Order ₹"+o.amount+"     Delivery fee ₹"+o.fee,14,GREEN,true));
        LinearLayout buttons=new LinearLayout(this); buttons.setPadding(0,dp(9),0,0);
        TextView map=action("MAP",Color.rgb(60,110,170));
        buttons.addView(map,new LinearLayout.LayoutParams(0,dp(42),1));
        map.setOnClickListener(v->openMap(o));
        if(o.status.equals("Assigned")){
            TextView accept=action("ACCEPT",GREEN); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1); p.leftMargin=dp(6); buttons.addView(accept,p);
            accept.setOnClickListener(v->{setStatus(o,"Accepted");showDashboard();});
            TextView reject=action("REJECT",Color.rgb(180,65,55)); p=new LinearLayout.LayoutParams(0,dp(42),1); p.leftMargin=dp(6); buttons.addView(reject,p);
            reject.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reject order?")
                .setMessage("This demo will hide the order locally.")
                .setNegativeButton("Cancel",null).setPositiveButton("Reject",(d,w)->{o.rejected=true;showDashboard();}).show());
        } else if(o.status.equals("Accepted")){
            addStatusButton(buttons,"PICKED UP",o,"Picked Up");
        } else if(o.status.equals("Picked Up")){
            addStatusButton(buttons,"OUT FOR DELIVERY",o,"Out for Delivery");
        } else if(o.status.equals("Out for Delivery")){
            addStatusButton(buttons,"COMPLETE DELIVERY",o,"Delivered");
        }
        card.addView(buttons);
        if(o.status.equals("Out for Delivery")){
            TextView otp=label("Demo delivery OTP: "+o.otp,12,Color.GRAY,false);
            otp.setPadding(0,dp(8),0,0); card.addView(otp);
        }
    }

    private void addStatusButton(LinearLayout row,String title,Order o,String next) {
        TextView b=action(title,GREEN); row.addView(b,new LinearLayout.LayoutParams(-1,dp(42)));
        b.setOnClickListener(v->{
            if(next.equals("Delivered")){
                EditText input=new EditText(this); input.setHint("Enter 4-digit customer OTP"); input.setInputType(2);
                new AlertDialog.Builder(this).setTitle("Confirm delivery").setView(input)
                    .setNegativeButton("Cancel",null).setPositiveButton("Verify",(d,w)->{
                        if(input.getText().toString().equals(o.otp)){setStatus(o,"Delivered");showDashboard();}
                        else toast("Incorrect demo OTP");
                    }).show();
            } else {setStatus(o,next);showDashboard();}
        });
    }

    private void setStatus(Order o,String s) {
        o.status=s; prefs.edit().putString("status_"+o.id,s).apply();
        toast("Order "+o.id+" updated: "+s);
    }

    private void openMap(Order o) {
        try {
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="+Uri.encode(o.address)));
            i.setPackage("com.google.android.apps.maps"); startActivity(i);
        } catch(Exception e) {
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/search/?api=1&query="+Uri.encode(o.address)));
            startActivity(i);
        }
    }

    private void earningsContent() {
        heading("My earnings");
        int total=0, deliveries=0;
        for(Order o:orders) if(o.status.equals("Delivered")){total+=o.fee;deliveries++;}
        LinearLayout box=column(); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackground(shape(Color.WHITE,16));
        box.addView(label("DEMO TOTAL EARNINGS",12,Color.GRAY,true));
        box.addView(label("₹"+total,32,GREEN,true));
        box.addView(label(deliveries+" completed deliveries",14,DARK,false));
        content.addView(box);
        heading("Earning history");
        for(Order o:orders) if(o.status.equals("Delivered"))
            content.addView(label(o.id+"     "+o.customer+"     ₹"+o.fee,14,DARK,false));
    }

    private void profileContent() {
        heading("My profile");
        content.addView(label("Demo Delivery Partner",18,DARK,true));
        content.addView(label("Mobile: 9876543210",14,Color.GRAY,false));
        content.addView(label("Account type: Demo partner",14,Color.GRAY,false));
        TextView logout=action("LOG OUT",Color.rgb(175,60,55));
        LinearLayout.LayoutParams p=lp(-1,48); p.topMargin=dp(22); content.addView(logout,p);
        logout.setOnClickListener(v->{prefs.edit().putBoolean("logged_in",false).apply();currentTab="Home";showLogin();});
    }

    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
