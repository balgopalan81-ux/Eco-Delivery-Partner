package in.ecogrocery.delivery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val EcoGreen = Color(0xFF176B39)
private val EcoLight = Color(0xFFEAF4EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EcoApp() }
    }
}


@Composable
fun EcoApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(false) }
    var accepted by remember { mutableStateOf(false) }
    var delivered by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = lightColorScheme(primary = EcoGreen, secondary = EcoGreen)) {
        if (!loggedIn) LoginScreen { loggedIn = true }
        else MainScreen(page, { page = it }, online, { online = it }, accepted, { accepted = it }, delivered, { delivered = it })
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(EcoLight).padding(22.dp), verticalArrangement = Arrangement.Center) {
        Text("🌿 ECO GROCERY", color = EcoGreen, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("DELIVERY PARTNER", color = EcoGreen, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(28.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Partner Login", style = MaterialTheme.typography.headlineSmall, color = EcoGreen)
                Text("Demo mode — no live account yet")
                OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it }, label = { Text("Password / OTP") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("Enter demo app") }
            }
        }
    }
}

@Composable
fun MainScreen(page: String, onPage: (String) -> Unit, online: Boolean, setOnline: (Boolean) -> Unit,
              accepted: Boolean, setAccepted: (Boolean) -> Unit, delivered: Boolean, setDelivered: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().background(EcoLight)) {
        Column(Modifier.fillMaxWidth().background(EcoGreen).padding(18.dp)) {
            Text("ECO GROCERY", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("DELIVERY PARTNER", color = Color.White)
            Spacer(Modifier.height(12.dp))
            Text("Hello, Partner 👋", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Text("Ready for deliveries?", color = Color.White)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when(page) {
                "Home" -> {
                    Card { Column(Modifier.padding(16.dp)) {
                        Text("Availability", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(if(online) "You are ONLINE" else "You are OFFLINE", color = EcoGreen)
                            Switch(online, setOnline)
                        }
                        Text(if(online) "Demo: you can receive test orders." else "Go online to receive delivery orders.")
                    } }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryCard("Completed", if(delivered) "1" else "0", Modifier.weight(1f))
                        SummaryCard("Today's earnings", if(delivered) "₹60" else "₹0", Modifier.weight(1f))
                    }
                    OrderCard(accepted, delivered, setAccepted, { onPage("Delivery") }, setDelivered)
                }
                "Orders" -> OrderCard(accepted, delivered, setAccepted, { onPage("Delivery") }, setDelivered)
                "Delivery" -> DeliveryCard(accepted, delivered, setAccepted, setDelivered)
                "Earnings" -> Card { Column(Modifier.padding(18.dp)) {
                    Text("Earnings overview", style = MaterialTheme.typography.titleLarge, color = EcoGreen)
                    Text("Today's demo earnings: ${if(delivered) "₹60" else "₹0"}")
                    Text("Completed deliveries: ${if(delivered) 1 else 0}")
                    Text("Demo amount only; actual payout rules not connected.")
                } }
            }
        }
        NavigationBar(containerColor = Color.White) {
            listOf("Home", "Orders", "Delivery", "Earnings").forEach { item ->
                NavigationBarItem(selected = page == item, onClick = { onPage(item) }, icon = { Text(when(item){"Home"->"⌂";"Orders"->"≡";"Delivery"->"➜";else->"₹"}) }, label = { Text(item) })
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall)
            Text(value, color = EcoGreen, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun OrderCard(accepted: Boolean, delivered: Boolean, setAccepted: (Boolean) -> Unit, openDelivery: () -> Unit, setDelivered: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Today's sample order", color = EcoGreen, fontWeight = FontWeight.Bold)
            Text("ECO-1024 · 12 grocery items")
            Text("Delivery area: Jaganpura, Patna")
            Text(if(delivered) "Status: Delivered" else if(accepted) "Status: Accepted" else "Status: New demo order")
            if(!accepted && !delivered) Button(onClick = { setAccepted(true) }, modifier = Modifier.fillMaxWidth()) { Text("Accept demo order") }
            if(accepted && !delivered) OutlinedButton(onClick = openDelivery, modifier = Modifier.fillMaxWidth()) { Text("Open delivery") }
            if(delivered) Text("Completed ✓", color = EcoGreen)
        }
    }
}
@Composable
fun DeliveryCard(accepted: Boolean, delivered: Boolean, setAccepted: (Boolean) -> Unit, setDelivered: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Delivery details", style = MaterialTheme.typography.titleLarge, color = EcoGreen)
            Text("Order ECO-1024")
            Text("Demo Customer")
            Text("Jaganpura, Patna, Bihar")
            Text("Customer call and map navigation will be connected in a future version.")
            if(!accepted) Button(onClick = { setAccepted(true) }, modifier = Modifier.fillMaxWidth()) { Text("Accept order") }
            else if(!delivered) Button(onClick = { setDelivered(true) }, modifier = Modifier.fillMaxWidth()) { Text("Mark as delivered") }
            else Text("Delivered successfully ✓", color = EcoGreen, fontWeight = FontWeight.Bold)
        }
    }
}
