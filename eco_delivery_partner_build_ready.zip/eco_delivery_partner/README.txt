ECO GROCERY DELIVERY PARTNER — Android starter project

This is a starter Android project source. It is demo-only and has no live login, server, real orders, GPS, calling, or payments.\n
Open using Android Studio on a computer to build. Phone-only build steps can be explored via a cloud build service, but this source has not been compiled or tested yet.

Package: in.ecogrocery.delivery
Demo order: ECO-1024
